#!/usr/bin/python
import json
from bson import json_util
from pymongo import MongoClient
import pprint
import datetime

# Database connection and selection
connection = MongoClient('localhost', 27017)
db = connection['market']
collection = db['stocks']

# Create new document in data base
def create_document(document):
	try:
		result=collection.insert_one(document)
		print("The Document has been successfully created!\n")
	except Exception as ve:
		abort(400, str(ve))
	return result

# Reads document based of predetermined query input
def read_document(query):
	try:
		result=collection.find_one(query)
		print(type(result))
		print(result)
	except Exception as ve:
		abort(400, str(ve))
	return result

# Update document based of predetermined query input
def update_document(criteria, document):
	try:
		collection.update_one(criteria,{"$set" : document})
		result = collection.find(criteria)
		print("The Document has successfully updated with your update information!")
	except Exception as ve:
		abort(400, str(ve))
	return result 


# Deletes document based of predetermined query input
def delete_document(document):
	try:
		result=collection.delete_one(document)
		print("The Document you have selected has been Deleted succesfully!")
	except Exception as ve:
		abort(400, str(ve))
	return result


# Main function to run opperations and call functions
def main():
	date = datetime.datetime.now()
	i = 0

	# Loop to run all services
	while i < 1:
		print("The following operations are available:")
		print(" : 1 :   Create/input a Document")
		print(" : 2 :   Read/Find a Document")
		print(" : 3 :   Update/Change a Document")
		print(" : 4 :   Delete/remove a Document")
		print(" : 5 :   Run an Aggregation Pipeline")
		print(" : 6 :   Exit Service Program")

		operation = input("From the list above, please type the number of the operation you would like to perform: ")

		# Calls Create Service
		if operation == 1:
			print("You have selected to Create/Input a Document\n")
			input_info = input("Please enter a Document that you would like to CREATE: \n")
			create_document(input_info)

		# Calls Read/Find Service
		elif operation == 2:
			print("You have selected to Read/Find a Document\n")
			search_info = input("Please enter a Document that you would like to RETRIEVE: \n")
			read_document(search_info)

		# Calls Update/Change Service
		elif operation == 3:
			print("You have selected to Update/Change a Document\n")
			doc_info = input("Please enter Document you intend to UPDATE\n")
			criteria_info = input("Please enter criteria of Document that you would like to update\n")
			update_document(doc_info, criteria_info)
			print("Below is the document you have selected to UPDATE with new updates.\n")
			read_document(doc_info)

		# Calls Delete/Remove Service
		elif operation == 4:
			print("You have selected to Delete/Remove a Document\n")
			delete_info = input("Please enter a Document that you would like to DELETE: \n")
			delete_document(delete_info)

		# Calls Aggregation Pipeline Service
		elif operation == 5:
			print("You have selected to Run an Aggregation Pipeline\n")
			print("The following Aggregation Pipelines are available:")
			print(" : 1 :   Pipeline One")
			print(" : 2 :   Pipeline Two")
			print(" : 3 :   Pipeline Three")
			print(" : 4 :   To Return to Main Service Screen")

			operationPL = input("Please type the number of the Aggregation Pipeline that you would like to run: ")

			# Calls Aggregation Pipeline One
			if operationPL == 1:
				print("You have selected Pipeline One\n")
				print("Pipeline Aggregation Complete\n")

			# Calls Aggregation Pipeline Two
			elif operationPL == 2:
				print("You have selected Pipeline Two\n")
				print("Pipeline Aggregation Complete\n")

			# Calls Aggregation Pipeline Three
			elif operationPL == 3:
				print("You have selected Pipeline Three\n")
				print("Pipeline Aggregation Complete\n")
			
			# Ends Aggregation Pipeline
			else:
				print("You have made an invalid selection or have selected to Return to the Main Screen")
				print("Please Run an Aggregation Pipeline again if desired\n")

		# Ends Service Loop
		elif operation == 6:
			print("\n")
			break

		# Returns Service Loop
		else:
			print("You have made an invalid selection, please try again\n")
			print("\n")
	print("You have selected to exit the Service Program is, Thank you!   Goodbye! \n")

# Runs python script as a program
if __name__ == '__main__':
	main()